document.addEventListener("DOMContentLoaded", () => {
    const filterCompletedBtn = document.getElementById("filterCompleted");
    const filtersContainer = document.getElementById("filters");

    if (filterCompletedBtn) {
        filterCompletedBtn.addEventListener("click", () => {
            const currentUrl = new URL(window.location.href);
            const showCompleted = currentUrl.searchParams.get("completed") === "true";

            if (showCompleted) {
                currentUrl.searchParams.delete("completed");
            } else {
                currentUrl.searchParams.set("completed", "true");
            }
            window.location.href = currentUrl.toString();
        });
    }

    if (filtersContainer) {
        filtersContainer.addEventListener("click", () => {
            const target = event.target;
            const sortingValue = target.getAttribute("data-sort");
            if (!sortingValue) return;

            const currentUrl = new URL(window.location.href);
            const currentOrder = currentUrl.searchParams.get("orderDirection");
            const newOrder = currentOrder === "desc" ? "asc" : "desc";

            currentUrl.searchParams.set("orderBy", sortingValue);
            currentUrl.searchParams.set("orderDirection", newOrder);

            window.location.href = currentUrl.toString();
        });
    }

    // Uncomment and complete if implementing theme switching:
    /*
    const styleToggle = document.getElementById("style-toggle");
    if (styleToggle) {
        styleToggle.addEventListener("click", async () => {
            await changeTheme(); // Ensure changeTheme() exists and returns a Promise
        });
    }
    */
});
